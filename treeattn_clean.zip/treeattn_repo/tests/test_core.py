"""Run with: python -m pytest tests -q   (CPU is fine, everything is tiny)."""
import os
import sys

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from treeattn import Config, TreeGPT
from treeattn.spike import Spike
from treeattn.tasks import NeedleTask
from treeattn.tree import build_levels, next_pow2, tree_descent


def small_cfg(**kw):
    base = dict(vocab_size=64, n_layer=2, n_head=2, n_embd=64, rot_dims=8, wmax=8, beam_classes=(2, 3, 4, 6, 8), q_chunk=32)
    base.update(kw)
    return Config(**base)


def arm_spike(model, thr=1.1):
    for blk in model.blocks:
        blk.attn.spike.thr.fill_(thr)
        blk.attn.spike.thr_init.fill_(1.0)


def test_descent_covers_exactly_the_past():
    torch.manual_seed(0)
    T = 64
    k = torch.randn(1, 1, T, 8)
    S = build_levels(k, next_pow2(T))
    tq = torch.arange(T)
    ids, vld, _ = tree_descent(torch.randn(1, 1, T, 8), S, tq, wmax=64)
    for t in range(T):
        got = sorted(ids[0, 0, t][vld[0, 0, t]].tolist())
        want = [m for m in range(T // 2) if 2 * m + 1 < t]       # leaves entirely before t
        assert got == want, (t, got, want)


def test_spike_is_causal_and_flags_outlier():
    cfg = small_cfg()
    sp = Spike(cfg, 1)
    k = torch.randn(1, 1, 200, 8)
    tq = torch.arange(200)
    s1 = sp.scores(k, tq)
    k2 = k.clone()
    k2[:, :, 150:] += 5.0                                     # change the future of position 100
    s2 = sp.scores(k2, tq)
    assert torch.allclose(s1[:, :, :150], s2[:, :, :150])
    k3 = k.clone()
    k3[:, :, 120] += 10.0 * torch.randn(8)
    assert sp.scores(k3, tq)[0, 0, 120] > 3 * s1[0, 0, 120].clamp(min=1.0)


def test_no_future_leak_with_amplification():
    torch.manual_seed(1)
    model = TreeGPT(small_cfg()).eval()
    arm_spike(model)
    x = torch.randint(0, 64, (1, 128))
    base, _, _ = model(x)
    j = 90
    x2 = x.clone()
    x2[0, j:] = torch.randint(0, 64, (128 - j,))
    alt, _, _ = model(x2)
    assert torch.allclose(base[:, :j], alt[:, :j], atol=1e-5), (base[:, :j] - alt[:, :j]).abs().max()


def test_decode_matches_parallel():
    torch.manual_seed(2)
    model = TreeGPT(small_cfg()).eval()
    arm_spike(model)
    x = torch.randint(0, 64, (1, 96))
    full, _, _ = model(x)
    caches = model.new_caches(1, 96)
    lg, _, _ = model(x[:, :48], caches=caches)
    outs = [lg]
    for t in range(48, 96):
        lg, _, _ = model(x[:, t:t + 1], caches=caches)
        outs.append(lg)
    step = torch.cat(outs, 1)
    assert torch.allclose(full, step, atol=1e-3), (full - step).abs().max()


def test_train_step_gives_gradients_to_both_trainable_functions():
    torch.manual_seed(3)
    task = NeedleTask(n_filler=32, n_key=8, n_val=8)
    cfg = small_cfg(vocab_size=task.vocab_size)
    model = TreeGPT(cfg).train()
    idx, y, route, _ = task.sample(2, 256, n_needles=3)
    for _ in range(2):                                          # second step has an initialised spike threshold
        model.zero_grad()
        _, loss, st = model(idx, y, route)
        loss.backward()
    assert torch.isfinite(loss)
    a = model.blocks[1].attn
    assert a.qkv.weight.grad.abs().sum() > 0                     # splitter
    assert a.pred[0].weight.grad is not None and a.pred[0].weight.grad.abs().sum() > 0   # budget predictor
    assert st['route'] != 0.0


def test_needle_task_layout():
    task = NeedleTask(n_filler=32, n_key=8, n_val=8)
    idx, y, (qpos, tgt), ans = task.sample(3, 300, n_needles=4, depth=0.5)
    assert idx.shape == (3, 300) and (y != -100).sum(1).tolist() == [3, 3, 3]
    for i in range(3):
        assert idx[i, qpos[i]] == task.IS
        assert idx[i, tgt[i]] == ans[i, 0]
