"""Language-model stage: train the full mini LLM (tree attention + FFN) on packed TinyStories windows, then report
validation loss by position bucket at a longer evaluation length (long-context behaviour)."""
import argparse
import math
import os
import sys
import time

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from treeattn import Config, TreeGPT

p = argparse.ArgumentParser()
p.add_argument('--data_dir', default='data/tinystories')
p.add_argument('--out', default='runs/lm')
p.add_argument('--seq_len', type=int, default=1024)
p.add_argument('--eval_len', type=int, default=4096)
p.add_argument('--batch', type=int, default=8)
p.add_argument('--steps', type=int, default=3000)
p.add_argument('--lr', type=float, default=1e-3)
p.add_argument('--n_layer', type=int, default=6)
p.add_argument('--n_head', type=int, default=6)
p.add_argument('--n_embd', type=int, default=384)
p.add_argument('--vocab', type=int, default=8192)
p.add_argument('--log_every', type=int, default=100)
a = p.parse_args()
dev = 'cuda' if torch.cuda.is_available() else 'cpu'
cfg = Config(vocab_size=a.vocab, n_layer=a.n_layer, n_head=a.n_head, n_embd=a.n_embd, route_weight=0.0, rot_dims=16)
model = TreeGPT(cfg).to(dev)
tr = np.memmap(os.path.join(a.data_dir, 'train.bin'), dtype=np.uint16, mode='r')
va = np.memmap(os.path.join(a.data_dir, 'val.bin'), dtype=np.uint16, mode='r')
rng = np.random.default_rng(0)


def batch(data, b, T):
    ix = rng.integers(0, len(data) - T - 1, size=b)
    x = torch.from_numpy(np.stack([data[i:i + T].astype(np.int64) for i in ix]))
    y = torch.from_numpy(np.stack([data[i + 1:i + 1 + T].astype(np.int64) for i in ix]))
    return x.to(dev), y.to(dev)


opt = torch.optim.AdamW(model.parameters(), lr=a.lr, betas=(0.9, 0.95), weight_decay=0.1)
use_amp = dev == 'cuda'
scaler = torch.amp.GradScaler('cuda', enabled=use_amp)
os.makedirs(a.out, exist_ok=True)
t0 = time.time()
for step in range(a.steps):
    lr = a.lr * min(1.0, (step + 1) / 100) * (0.1 + 0.9 * 0.5 * (1 + math.cos(math.pi * step / a.steps)))
    for g in opt.param_groups:
        g['lr'] = lr
    model.train()
    x, y = batch(tr, a.batch, a.seq_len)
    with torch.autocast(dev, dtype=torch.float16, enabled=use_amp):
        _, loss, st = model(x, y)
    opt.zero_grad(set_to_none=True)
    scaler.scale(loss).backward()
    scaler.unscale_(opt)
    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
    scaler.step(opt)
    scaler.update()
    if step % a.log_every == 0:
        print('step %d | lm %.3f pred %.3f | keys %.1f flag %.3f | %.2fs/step' % (
            step, st['lm'], st['pred'], st.get('keys', 0), st.get('flag_frac', 0), (time.time() - t0) / (step + 1)), flush=True)
torch.save({'cfg': cfg.to_dict(), 'model': model.state_dict()}, os.path.join(a.out, 'ckpt.pt'))

model.eval()
for T in sorted({a.seq_len, a.eval_len}):
    tot, n = None, 0
    with torch.no_grad():
        for _ in range(8):
            x, y = batch(va, 1, T)
            with torch.autocast(dev, dtype=torch.float16, enabled=use_amp):
                lg, _, _ = model(x)
            ce = torch.nn.functional.cross_entropy(lg.float().view(-1, lg.size(-1)), y.view(-1), reduction='none')
            tot = ce if tot is None else tot + ce
            n += 1
    ce = (tot / n).cpu()
    edges = [0, 256, 512, 1024, 2048, 4096, 8192, 16384]
    print('val loss at T=%d by position: ' % T + ' '.join('[%d,%d):%.3f' % (lo, min(hi, T), ce[lo:hi].mean()) for lo, hi in zip(edges, edges[1:]) if lo < T), flush=True)
