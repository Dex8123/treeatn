"""Train on the needle task with a length curriculum, then report recall by length x depth.
The routing loss (--route_weight) is what teaches the splitter to make the needle's index keys findable."""
import argparse
import math
import os
import sys
import time

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from treeattn import Config, TreeGPT
from treeattn.evaluate import needle_accuracy
from treeattn.tasks import NeedleTask

p = argparse.ArgumentParser()
p.add_argument('--out', default='runs/needle')
p.add_argument('--lengths', default='512,1024,2048,4096')
p.add_argument('--steps', type=int, default=600, help='steps per length stage')
p.add_argument('--tokens_per_batch', type=int, default=16384)
p.add_argument('--n_needles', type=int, default=4)
p.add_argument('--lr', type=float, default=1e-3)
p.add_argument('--n_layer', type=int, default=4)
p.add_argument('--n_head', type=int, default=4)
p.add_argument('--n_embd', type=int, default=256)
p.add_argument('--wmax', type=int, default=16)
p.add_argument('--spike', type=int, default=1)
p.add_argument('--route_weight', type=float, default=0.1)
p.add_argument('--budget_mode', default='pred')
p.add_argument('--filler_bin', default='')
p.add_argument('--eval_lengths', default='1024,4096,16384')
p.add_argument('--log_every', type=int, default=50)
p.add_argument('--seed', type=int, default=0)
a = p.parse_args()

torch.manual_seed(a.seed)
dev = 'cuda' if torch.cuda.is_available() else 'cpu'
task = NeedleTask(filler_bin=a.filler_bin or None, seed=a.seed)
cfg = Config(vocab_size=task.vocab_size, n_layer=a.n_layer, n_head=a.n_head, n_embd=a.n_embd, wmax=a.wmax,
             spike=bool(a.spike), route_weight=a.route_weight, budget_mode=a.budget_mode)
model = TreeGPT(cfg).to(dev)
print('device', dev, '| params %.2fM | vocab %d' % (sum(p.numel() for p in model.parameters()) / 1e6, cfg.vocab_size))
opt = torch.optim.AdamW(model.parameters(), lr=a.lr, betas=(0.9, 0.95), weight_decay=0.01)
use_amp = dev == 'cuda'
scaler = torch.amp.GradScaler('cuda', enabled=use_amp)
lengths = [int(v) for v in a.lengths.split(',')]
total, step = a.steps * len(lengths), 0
os.makedirs(a.out, exist_ok=True)

for T in lengths:
    b = max(1, a.tokens_per_batch // T)
    t0 = time.time()
    for it in range(a.steps):
        lr = a.lr * min(1.0, (step + 1) / 100) * (0.1 + 0.9 * 0.5 * (1 + math.cos(math.pi * step / total)))
        for g in opt.param_groups:
            g['lr'] = lr
        model.train()
        idx, y, route, _ = task.sample(b, T, n_needles=a.n_needles)
        idx, y, route = idx.to(dev), y.to(dev), tuple(r.to(dev) for r in route)
        with torch.autocast(dev, dtype=torch.float16, enabled=use_amp):
            _, loss, st = model(idx, y, route)
        opt.zero_grad(set_to_none=True)
        scaler.scale(loss).backward()
        scaler.unscale_(opt)
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        scaler.step(opt)
        scaler.update()
        step += 1
        if it % a.log_every == 0 or it == a.steps - 1:
            print('T %d step %d | lm %.3f route %.3f pred %.3f | keys %.1f flag %.3f | %.2fs/step' % (
                T, step, st['lm'], st['route'], st['pred'], st.get('keys', 0), st.get('flag_frac', 0),
                (time.time() - t0) / (it + 1)), flush=True)
    r = needle_accuracy(model, task, T, depths=(0.1, 0.5, 0.9), n=16, n_needles=a.n_needles, amp=use_amp)
    print('  recall at T=%d (first token / all three): ' % T + ' '.join('d%.1f:%.2f/%.2f' % (d, v[0], v[1]) for d, v in r.items()), flush=True)
    torch.save({'cfg': cfg.to_dict(), 'model': model.state_dict(), 'task': dict(n_filler=task.n_filler, n_key=task.n_key, n_val=task.n_val)},
               os.path.join(a.out, 'ckpt.pt'))

print('\n=== FINAL: needle recall, first token / all three (chance ~ %.3f)' % (1.0 / task.n_val))
for T in [int(v) for v in a.eval_lengths.split(',')]:
    r = needle_accuracy(model, task, T, n=24, n_needles=a.n_needles, amp=use_amp)
    print('T=%6d | ' % T + ' '.join('d%.2f:%.2f/%.2f' % (d, v[0], v[1]) for d, v in r.items()) + ' | keys read %.1f' % list(r.values())[0][2], flush=True)
