from dataclasses import dataclass, asdict


@dataclass
class Config:
    # ---- model
    vocab_size: int = 8192
    seq_len: int = 1024            # only used for the optional absolute position table and defaults
    n_layer: int = 4
    n_head: int = 4
    n_embd: int = 256
    rot_dims: int = 16             # head dims that carry rotary position (exact attention only, NOT indexed by the tree)
    rope_base: float = 10000.0
    abs_pos: bool = False          # learned absolute positions instead of rotary (cannot extrapolate past seq_len)

    # ---- tree search
    wmax: int = 16                 # beam width: max tree nodes kept per level
    local: int = 3                 # static recent keys: t, t-1, t-2 (the sink at position 0 is always added too)
    max_keys: int = 40             # hard cap on keys read per query (priority: static > tree > neighbours)
    q_chunk: int = 1024            # queries processed at once (bounds memory, any sequence length)

    # ---- budget predictor (trainable function 2)
    budget_mode: str = 'pred'      # 'pred' or 'fixed'
    fixed_budget: int = 4          # leaf groups (2 keys each) when budget_mode == 'fixed'
    beam_classes: tuple = (2, 3, 4, 6, 8)
    pred_hidden: int = 64
    pred_weight: float = 0.1

    # ---- neighbour search
    neighbors: bool = True
    nb_window: int = 8             # how many earlier queries a query may borrow from
    nb_store: int = 2              # best tree leaves each query stores for its neighbours
    nb_level: int = 1              # 1 = groups of 2 keys, 2 = groups of 4 keys, ...
    nb_rho: float = 0.35           # a borrowed group matches if new score >= old score - rho * |old score|
    nb_probe: int = 3              # nearest queries used to estimate the match rate (sets the variable cap)
    nb_cap_min: int = 2

    # ---- spike detector + amplification
    spike: bool = True
    spike_win: int = 64            # trailing window (previous keys only)
    spike_min_hist: int = 16
    spike_score: str = 'rms'       # 'rms' (RMS of per-dim z) or 'max' (worst dimension)
    spike_q: float = 0.98          # threshold = running quantile of natural scores (frozen at inference)
    spike_ema: float = 0.99
    spike_amp: float = 1.0         # multiplier = 1 + amp * d * min(relu(score/thr - 1), cap)
    spike_cap: float = 4.0

    # ---- routing loss (teaches the splitter to make important keys findable; needs `route` targets)
    route_weight: float = 0.1
    route_neg: int = 16
    route_min_layer: int = 1

    def to_dict(self):
        return asdict(self)

    @property
    def head_dim(self):
        return self.n_embd // self.n_head

    @property
    def content_dim(self):
        return self.head_dim - self.rot_dims
