"""Needle-in-a-haystack task (token level, any length).

Sequence layout (x has T + 1 tokens, input = x[:T], target = x[1:]):
    filler ... [SEP K1 K2 IS V1 V2 V3] ... filler ... (distractor needles with other keys) ... [QRY K1 K2 IS] V1 V2 V3
The loss is only on the three value tokens at the end. The model has to find the needle whose key matches the
question, at any depth, in a haystack of up to 64k+ tokens. Filler is random Zipf-like tokens, or real text tokens
if `filler_bin` (uint16 token file, ids < n_filler) is given.

Vocabulary: [0, n_filler) filler, then SEP, QRY, IS, then n_key key tokens, then n_val value tokens.
"""
import numpy as np
import torch

KEY_LEN, VAL_LEN = 2, 3
NEEDLE_LEN = 1 + KEY_LEN + 1 + VAL_LEN        # SEP K K IS V V V
QUERY_LEN = 1 + KEY_LEN + 1 + VAL_LEN         # QRY K K IS V V V


class NeedleTask:
    def __init__(self, n_filler=8192, n_key=64, n_val=64, filler_bin=None, seed=0):
        self.n_filler, self.n_key, self.n_val = n_filler, n_key, n_val
        self.SEP, self.QRY, self.IS = n_filler, n_filler + 1, n_filler + 2
        self.key0, self.val0 = n_filler + 3, n_filler + 3 + n_key
        self.vocab_size = self.val0 + n_val
        self.rng = np.random.default_rng(seed)
        self.filler = np.memmap(filler_bin, dtype=np.uint16, mode='r') if filler_bin else None
        if self.filler is None:
            p = 1.0 / np.arange(1, n_filler + 1)
            self.p = p / p.sum()

    def _filler(self, n):
        if self.filler is not None:
            i = int(self.rng.integers(0, len(self.filler) - n - 1))
            return np.minimum(self.filler[i:i + n].astype(np.int64), self.n_filler - 1)
        return self.rng.choice(self.n_filler, size=n, p=self.p)

    def sample(self, b, T, n_needles=4, depth=None):
        """Returns idx (b,T), targets (b,T) (-100 except the 3 answer slots), route = (qpos, tgt), answers (b,3).
        depth in [0,1] fixes where the TARGET needle sits (fraction of the filler); None = random."""
        assert T > NEEDLE_LEN * (n_needles + 1) + QUERY_LEN + 8
        slot = T + 1 - QUERY_LEN - n_needles * NEEDLE_LEN          # number of filler tokens
        xs, qpos, tgt = [], [], []
        for _ in range(b):
            keys = self.rng.choice(self.n_key ** KEY_LEN, size=n_needles, replace=False)
            vals = self.rng.integers(0, self.n_val, size=(n_needles, VAL_LEN))
            cuts = self.rng.integers(0, slot + 1, size=n_needles)
            target = int(self.rng.integers(0, n_needles))
            if depth is not None:
                cuts[target] = int(depth * slot)
            order = np.argsort(cuts, kind='stable')
            cuts, keys, vals = cuts[order], keys[order], vals[order]
            target = int(np.where(order == target)[0][0])
            filler = self._filler(slot)
            seq, used, tpos = [], 0, 0
            for j in range(n_needles):
                seq.append(filler[used:cuts[j]])
                used = int(cuts[j])
                kt = [self.key0 + (int(keys[j]) // self.n_key ** (KEY_LEN - 1 - m)) % self.n_key for m in range(KEY_LEN)]
                if j == target:
                    tpos = sum(len(s) for s in seq)
                    tkeys = kt
                seq.append(np.array([self.SEP] + kt + [self.IS] + [self.val0 + int(v) for v in vals[j]], dtype=np.int64))
            seq.append(filler[used:])
            seq.append(np.array([self.QRY] + tkeys + [self.IS] + [self.val0 + int(v) for v in vals[target]], dtype=np.int64))
            full = np.concatenate(seq)
            assert len(full) == T + 1, (len(full), T + 1)
            xs.append(full)
            qpos.append(T - VAL_LEN)                                  # input position of the question's IS
            tgt.append(tpos + 1 + KEY_LEN + 1)                        # position of V1 inside the target needle
        X = torch.from_numpy(np.stack(xs))
        idx, y = X[:, :T].clone(), X[:, 1:].clone()
        mask = torch.full_like(y, -100)
        mask[:, T - VAL_LEN:] = y[:, T - VAL_LEN:]
        return idx, mask, (torch.tensor(qpos), torch.tensor(tgt)), X[:, -VAL_LEN:].clone()
