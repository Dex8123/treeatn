"""Causal spike detector + graded amplification of keys for the tree's index sums.

Score of key t: compared with the previous `spike_win` keys only (trailing window), per dimension
z = (k_t - trailing mean) / trailing std; rms = RMS of z over dimensions, max = largest |z|. The window never
contains key t or anything later, so training does not leak, and in decoding it is a constant-size look-back.
Gradual drift is absorbed by the trailing mean; only abrupt irregular keys score high.

Amplification (graded): multiplier = 1 + amp * d * min(relu(score / thr - 1), cap), so the further a key is above
the threshold the harder it is amplified, and keys just above it are barely touched. Only the index sums see the
multiplier; the stored key used for exact attention is unchanged.
The threshold is a running quantile of natural scores, updated during training and frozen at inference.
Statistics (mean/std of the window) are constants; gradients flow through the current key only.
"""
import torch
import torch.nn as nn


class Spike(nn.Module):
    def __init__(self, cfg, n_head):
        super().__init__()
        self.cfg = cfg
        self.register_buffer('thr', torch.zeros(n_head))
        self.register_buffer('thr_init', torch.zeros(1))

    def _hist_stats(self, kbuf, tq):
        W = self.cfg.spike_win
        n_all = tq.shape[0]
        mus, sds, ns = [], [], []
        for s in range(0, n_all, 512):
            t = tq[s:s + 512]
            idx = t.view(-1, 1) - W + torch.arange(W, device=kbuf.device).view(1, W)
            valid = idx >= 1                                   # position 0 is the sink, never part of the history
            hist = kbuf[:, :, idx.clamp(min=0)].float()        # (b,H,n,W,d)
            vm = valid.view(1, 1, -1, W, 1)
            n = valid.sum(-1).clamp(min=1)
            nn_ = n.view(1, 1, -1, 1)
            mu = (hist * vm).sum(3) / nn_
            var = (((hist - mu.unsqueeze(3)) ** 2) * vm).sum(3) / nn_
            mus.append(mu)
            sds.append((var + 1e-6).sqrt())
            ns.append(valid.sum(-1))
        return torch.cat(mus, 2), torch.cat(sds, 2), torch.cat(ns, 0)

    def scores(self, kbuf, tq):
        """kbuf (b,H,Tbuf,d) raw content keys (positions < Tbuf), tq (N,) positions. Returns (b,H,N)."""
        with torch.no_grad():
            mu, sd, nh = self._hist_stats(kbuf, tq)
        z = (kbuf[:, :, tq].float() - mu) / sd
        if self.cfg.spike_score == 'max':
            s = z.abs().amax(-1)
        else:
            s = (z.pow(2).mean(-1) + 1e-8).sqrt()
        return s * (nh >= self.cfg.spike_min_hist).view(1, 1, -1).to(s.dtype)

    @torch.no_grad()
    def update(self, s):
        """EMA of the spike_q quantile of natural scores, per head. s (b,H,N). Training only."""
        b, H, N = s.shape
        x = s[:, :, self.cfg.spike_min_hist:].permute(1, 0, 2).reshape(H, -1).float()
        if x.shape[1] == 0:
            return
        if x.shape[1] > 1_000_000:
            x = x[:, torch.randperm(x.shape[1], device=x.device)[:1_000_000]]
        qv = torch.quantile(x, self.cfg.spike_q, dim=1)
        if self.thr_init.item() == 0:
            self.thr.copy_(qv)
            self.thr_init.fill_(1.0)
        else:
            self.thr.mul_(self.cfg.spike_ema).add_(qv * (1 - self.cfg.spike_ema))

    def multiplier(self, s, d):
        """s (b,H,N) -> multiplier (b,H,N) >= 1."""
        if self.thr_init.item() == 0:
            return torch.ones_like(s)
        thr = self.thr.clamp(min=1e-3).view(1, -1, 1)
        e = torch.relu(s / thr - 1.0).clamp(max=self.cfg.spike_cap)
        return 1.0 + self.cfg.spike_amp * d * e
