"""Sub-quadratic causal tree attention.

Trainable parts (everything else is parameter-free search):
  1. the splitter: one linear map x -> q, k, v
  2. the budget predictor: a small MLP (query + anti-dilution global vector -> how many leaf groups are needed)

Per query, in order: static keys (sink, self, previous local-1) -> neighbour search (borrow from earlier queries)
-> tree descent for whatever the budget still needs. Exact softmax attention runs only over the (<= max_keys)
selected keys. No dense T x T matrix exists anywhere. Training and decoding use the same functions; decoding keeps a
LayerCache (keys, values, tree levels, global sum, stored leaves) and costs O(wmax * log T + max_keys) per token.

Position handling: the first `rot_dims` dims of every head are rotated (RoPE) and used by exact attention only; the
remaining content dims are what the tree indexes. The tree therefore sums position-free content vectors.
"""
import math

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.checkpoint import checkpoint

from .spike import Spike
from .tree import (build_levels, gather_nodes, n_levels, neighbor_search, next_pow2, route_loss, select_unique,
                   split_budget, tree_descent)


class LayerCache:
    def __init__(self, cfg, b, tmax, device, dtype):
        H, dh, dc = cfg.n_head, cfg.head_dim, cfg.content_dim
        self.tmax, self.tpad = tmax, next_pow2(tmax)
        self.k = torch.zeros(b, H, tmax, dh, device=device, dtype=dtype)
        self.v = torch.zeros(b, H, tmax, dh, device=device, dtype=dtype)
        self.qc = torch.zeros(b, H, tmax, dc, device=device)
        self.S = build_levels(torch.zeros(b, H, self.tpad, dc, device=device), self.tpad)
        self.G = torch.zeros(b, H, dc, device=device)
        self.tops = torch.full((b, H, tmax, cfg.nb_store), -1, dtype=torch.long, device=device)
        self.t = 0


def rotary(x, pos, rot, base):
    if rot == 0:
        return x
    inv = 1.0 / (base ** (torch.arange(0, rot, 2, device=x.device).float() / rot))
    ang = pos.float().view(-1, 1) * inv.view(1, -1)
    cos, sin = ang.cos().to(x.dtype), ang.sin().to(x.dtype)
    x1, x2, rest = x[..., :rot // 2], x[..., rot // 2:rot], x[..., rot:]
    return torch.cat([x1 * cos - x2 * sin, x1 * sin + x2 * cos, rest], -1)


class TreeAttention(nn.Module):
    def __init__(self, cfg, layer=0):
        super().__init__()
        self.cfg, self.layer = cfg, layer
        C, H = cfg.n_embd, cfg.n_head
        self.H, self.dh, self.dc, self.rot = H, cfg.head_dim, cfg.content_dim, cfg.rot_dims
        assert C % H == 0 and self.dc > 0 and self.rot % 2 == 0
        assert cfg.wmax >= cfg.nb_store and max(cfg.beam_classes) <= cfg.wmax
        self.qkv = nn.Linear(C, 3 * C, bias=False)          # the splitter
        self.proj = nn.Linear(C, C, bias=False)
        self.spike = Spike(cfg, H)
        if cfg.budget_mode == 'pred':                       # the budget predictor
            fin = self.dc + 1 + H + self.dc + 1
            self.pred = nn.Sequential(nn.Linear(fin, cfg.pred_hidden), nn.ReLU(),
                                      nn.Linear(cfg.pred_hidden, len(cfg.beam_classes)))
            self.register_buffer('classes', torch.tensor(list(cfg.beam_classes)), persistent=False)
            self.register_buffer('head_eye', torch.eye(H), persistent=False)
        self.aux = {}

    # ------------------------------------------------------------------ budget predictor
    def _budget(self, qc, G):
        """qc (b,H,N,dc) content queries, G (b,H,N,dc) anti-dilution global vector (sum of all earlier index keys,
        spikes included at their amplified value). Returns (leaf-group budget (b,H,N) long, logits or None)."""
        b, H, N, _ = qc.shape
        if self.cfg.budget_mode != 'pred':
            return torch.full((b, H, N), self.cfg.fixed_budget, dtype=torch.long, device=qc.device), None
        qd, gn = qc.detach().float(), G.detach().float().norm(dim=-1, keepdim=True)
        feats = torch.cat([qd, torch.log(qd.norm(dim=-1, keepdim=True) + 1e-6),
                           self.head_eye.view(1, H, 1, H).expand(b, H, N, H),
                           G.detach().float() / (gn + 1e-6), torch.log1p(gn) / 10.0], -1)
        logits = self.pred(feats)
        return self.classes[logits.argmax(-1).detach()], logits

    # ------------------------------------------------------------------ exact attention over selected keys
    @staticmethod
    def _exact(q, kbuf, vbuf, pos, ok):
        kg, vg = gather_nodes(kbuf, pos.clamp(min=0)), gather_nodes(vbuf, pos.clamp(min=0))
        s = torch.einsum('bhnd,bhnkd->bhnk', q, kg).float() / math.sqrt(q.shape[-1])
        w = torch.softmax(s.masked_fill(~ok, float('-inf')), -1).to(vg.dtype)
        return torch.einsum('bhnk,bhnkd->bhnd', w, vg)

    @torch.no_grad()
    def _budget_label(self, q, kbuf, tree_pos, tree_ok, st, st_ok, cl):
        """Smallest class that covers 90% of the tree-leaf attention mass (leaves taken in search order).
        Also returns the share of attention the tree leaves get (weight for the loss)."""
        def sc(p):
            return torch.einsum('bhnd,bhnkd->bhnk', q.float(), gather_nodes(kbuf, p.clamp(min=0)).float()) / math.sqrt(q.shape[-1])
        logit = torch.cat([sc(st).masked_fill(~st_ok, float('-inf')), sc(tree_pos).masked_fill(~tree_ok, float('-inf'))], -1)
        w = torch.softmax(logit, -1)[..., st.shape[-1]:]
        mass = w[..., 0::2] + w[..., 1::2]
        total = mass.sum(-1)
        need = (mass.cumsum(-1) < 0.9 * total.unsqueeze(-1)).sum(-1) + 1
        label = (need.unsqueeze(-1) > cl).sum(-1).clamp(max=len(cl) - 1)
        return label, total

    # ------------------------------------------------------------------ forward
    def forward(self, x, cache=None, route=None):
        cfg = self.cfg
        b, T, C = x.shape
        H, dh, dc, rot = self.H, self.dh, self.dc, self.rot
        dev = x.device
        self.aux = {}
        q, k, v = [t.view(b, T, H, dh).transpose(1, 2) for t in self.qkv(x).split(C, 2)]
        t0 = cache.t if cache is not None else 0
        decode = cache is not None and t0 > 0
        assert not decode or T == 1, 'cached decoding takes one token at a time (prefill the prompt first)'
        tq = torch.arange(t0, t0 + T, device=dev)
        q, k = rotary(q, tq, rot, cfg.rope_base), rotary(k, tq, rot, cfg.rope_base)

        # ---- buffers visible to this call
        if cache is not None:
            cache.k[:, :, t0:t0 + T], cache.v[:, :, t0:t0 + T] = k.to(cache.k.dtype), v.to(cache.v.dtype)
            cache.qc[:, :, t0:t0 + T] = q[..., rot:].detach().float()
            kbuf, vbuf, qbuf = cache.k[:, :, :t0 + T], cache.v[:, :, :t0 + T], cache.qc[:, :, :t0 + T]
        else:
            kbuf, vbuf, qbuf = k, v, q[..., rot:].detach().float()

        # ---- spike detection and graded amplification (index sums only)
        kc = k[..., rot:]
        if cfg.spike:
            s = self.spike.scores(kbuf[..., rot:], tq)
            if self.training and not decode:
                self.spike.update(s.detach())
            mult = self.spike.multiplier(s, dc)
            self.aux['flag_frac'] = (mult[:, :, cfg.spike_min_hist:] > 1).float().mean().detach() if T > cfg.spike_min_hist else torch.zeros(())
        else:
            mult = torch.ones(b, H, T, device=dev)
        kidx = kc.float() * mult.unsqueeze(-1)
        kidx = kidx * (tq != 0).view(1, 1, T, 1).to(kidx.dtype)            # the sink is never indexed

        # ---- tree levels + anti-dilution global vector
        use_route = route is not None and self.training and self.layer >= cfg.route_min_layer and cfg.route_weight > 0
        if decode:
            for l in range(1, len(cache.S)):
                cache.S[l][:, :, t0 >> l] += kidx[:, :, 0]
            S, G = cache.S, cache.G.view(b, H, 1, dc).clone()
            cache.G += kidx[:, :, 0]
            tpad = cache.tpad
        else:
            tpad = cache.tpad if cache is not None else next_pow2(T)
            with torch.set_grad_enabled(use_route):
                S = build_levels(kidx, tpad)
            kd = kidx.detach()
            G = kd.cumsum(2) - kd
            if cache is not None:
                cache.S = [None] + [s_.detach().clone() for s_ in S[1:]]
                cache.G = kd.sum(2)
        Sd = [None] + [s_.detach() for s_ in S[1:]]

        # ---- budget predictor
        lhat, plog = self._budget(qbuf[:, :, t0:t0 + T], G)

        # ---- pass 1: tree descent for every query; each query stores its best leaves for its neighbours
        NS, chunk = cfg.nb_store, cfg.q_chunk
        spans = [(s0, min(s0 + chunk, T)) for s0 in range(0, T, chunk)]
        qf = qbuf[:, :, t0:t0 + T]
        tops = cache.tops if cache is not None else torch.full((b, H, T, NS), -1, dtype=torch.long, device=dev)
        found = []
        for s0, s1 in spans:
            ids, vld, _ = tree_descent(qf[:, :, s0:s1], Sd, tq[s0:s1], cfg.wmax)
            found.append((ids, vld))
            tops[:, :, t0 + s0:t0 + s1] = torch.where(vld[..., :NS], ids[..., :NS], torch.full_like(ids[..., :NS], -1))

        # ---- pass 2: neighbour search, budget split, key selection, exact attention
        outs, st_keys, st_tree, st_nb = [], 0.0, 0.0, 0.0
        pnum, pden = 0.0, 0.0
        ar_w = torch.arange(found[0][0].shape[-1], device=dev)
        lvk = 1 << cfg.nb_level
        for (s0, s1), (ids, vld) in zip(spans, found):
            n, tqc = s1 - s0, tq[s0:s1]
            grp, match, nL = neighbor_search(qf[:, :, s0:s1], qbuf, Sd, tqc, tops, cfg)
            n_tree = split_budget(lhat[:, :, s0:s1], nL, cfg.wmax)
            leaf_ok = vld & (ar_w[:ids.shape[-1]] < n_tree.unsqueeze(-1))
            tree_pos = (2 * ids.unsqueeze(-1) + torch.arange(2, device=dev)).flatten(-2)
            nb_pos = (grp.unsqueeze(-1) * lvk + torch.arange(lvk, device=dev)).flatten(-2)
            st = (tqc.view(1, 1, n, 1) - torch.arange(cfg.local, device=dev)).expand(b, H, n, cfg.local)
            st = torch.cat([torch.zeros(b, H, n, 1, dtype=torch.long, device=dev), st], -1)
            st_ok = st >= 0
            cand = torch.cat([st, tree_pos, nb_pos], -1)
            valid = torch.cat([st_ok, leaf_ok.repeat_interleave(2, -1), match.repeat_interleave(lvk, -1)], -1)
            pos, ok = select_unique(cand, valid, cfg.max_keys)
            qc_rows = q[:, :, s0:s1]
            if self.training and qc_rows.requires_grad:
                outs.append(checkpoint(self._exact, qc_rows, kbuf, vbuf, pos, ok, use_reentrant=False))
            else:
                outs.append(self._exact(qc_rows, kbuf, vbuf, pos, ok))
            if self.training and plog is not None:
                label, share = self._budget_label(qc_rows, kbuf, tree_pos, vld.repeat_interleave(2, -1), st, st_ok, self.classes)
                ce = F.cross_entropy(plog[:, :, s0:s1].float().reshape(-1, plog.shape[-1]), label.reshape(-1), reduction='none')
                pnum = pnum + (ce * share.reshape(-1)).sum()
                pden = pden + share.sum()
            st_keys = st_keys + ok.sum(-1).float().sum()
            st_tree = st_tree + leaf_ok.sum(-1).float().sum()
            st_nb = st_nb + nL.float().sum()
        denom = float(b * H * T)
        self.aux['keys'] = (st_keys / denom).detach()
        self.aux['leaves_used'] = (st_tree / denom).detach()
        self.aux['nb_leaves'] = (st_nb / denom).detach()
        if self.training and plog is not None:
            self.aux['pred'] = pnum / (pden + 1e-6)
        if use_route:
            qpos, tgt = route
            q_row = q[torch.arange(b, device=dev), :, qpos][..., rot:]
            self.aux['route'] = route_loss(q_row, S, qpos, tgt, cfg.route_neg)
        if cache is not None:
            cache.t = t0 + T
        out = torch.cat(outs, 2)
        return self.proj(out.transpose(1, 2).reshape(b, T, C))
