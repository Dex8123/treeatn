import torch


@torch.no_grad()
def needle_accuracy(model, task, T, depths=(0.0, 0.25, 0.5, 0.75, 1.0), n=32, n_needles=4, bs=2, amp=True):
    """Teacher-forced exact recall of the three value tokens. Returns {depth: (acc_first_token, acc_all_three, keys_read)}."""
    model.eval()
    dev = next(model.parameters()).device
    out = {}
    for d in depths:
        first = full = keys = cnt = 0.0
        for _ in range(0, n, bs):
            idx, y, _, ans = task.sample(bs, T, n_needles=n_needles, depth=d)
            with torch.autocast(dev.type, dtype=torch.float16, enabled=amp and dev.type == 'cuda'):
                logits, _, st = model(idx.to(dev))
            pred = logits[:, -3:].argmax(-1).cpu()
            first += (pred[:, 0] == ans[:, 0]).float().sum().item()
            full += (pred == ans).all(1).float().sum().item()
            keys += st.get('keys', 0.0) * bs
            cnt += bs
        out[d] = (first / cnt, full / cnt, keys / cnt)
    return out
